import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { Game, getBestScore, type GameStats, type UpgradeDef } from "./game/game";
import titleBg from "./assets/title-bg.jpg";
import nebulaBg from "./assets/nebula.jpg";

type Screen = "menu" | "how" | "game";

const rarityTint: Record<UpgradeDef["rarity"], string> = {
  common: "from-cyan-400/20 to-cyan-400/5 border-cyan-300/40",
  rare: "from-fuchsia-500/25 to-fuchsia-500/5 border-fuchsia-400/45",
  epic: "from-amber-300/25 to-amber-400/5 border-amber-300/50",
};

const rarityText: Record<UpgradeDef["rarity"], string> = {
  common: "text-cyan-300",
  rare: "text-fuchsia-300",
  epic: "text-amber-300",
};

function formatTime(s: number) {
  const m = Math.floor(s / 60);
  const r = Math.floor(s % 60);
  return `${m}:${r.toString().padStart(2, "0")}`;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [screen, setScreen] = useState<Screen>("menu");
  const [paused, setPaused] = useState(false);
  const [upgrades, setUpgrades] = useState<UpgradeDef[] | null>(null);
  const [over, setOver] = useState<GameStats | null>(null);
  const [muted, setMuted] = useState(false);
  const [best, setBest] = useState(0);
  const [touch, setTouch] = useState(false);
  const [run, setRun] = useState(0);

  useEffect(() => {
    setBest(getBestScore());
    setTouch(window.matchMedia("(pointer: coarse)").matches);
    try {
      const m = localStorage.getItem("pulsar-muted") === "1";
      setMuted(m);
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    if (screen !== "game") return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const game = new Game(canvas, {
      onUpgrade: (choices) => setUpgrades(choices),
      onGameOver: (stats) => {
        setOver(stats);
        setBest(stats.best);
        setUpgrades(null);
        setPaused(false);
      },
      onPause: (p) => setPaused(p),
    });
    gameRef.current = game;
    game.autoAim = window.matchMedia("(pointer: coarse)").matches;
    game.setMuted(muted);
    (document.activeElement as HTMLElement | null)?.blur();
    void game.start();
    return () => {
      game.destroy();
      gameRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [screen, run]);

  const toggleMute = useCallback(() => {
    setMuted((m) => {
      const next = !m;
      gameRef.current?.setMuted(next);
      try {
        localStorage.setItem("pulsar-muted", next ? "1" : "0");
      } catch {
        /* ignore */
      }
      return next;
    });
  }, []);

  const begin = () => {
    setOver(null);
    setPaused(false);
    setUpgrades(null);
    setScreen("game");
    setRun((n) => n + 1);
  };

  const pick = (id: string) => {
    gameRef.current?.chooseUpgrade(id);
    setUpgrades(null);
  };

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#05010d] text-[#e7f7ff]">
      {screen === "game" && (
        <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />
      )}

      <div className="scanlines pointer-events-none absolute inset-0 z-20 opacity-40" />

      {screen === "menu" && (
        <Menu
          best={best}
          muted={muted}
          onStart={begin}
          onHow={() => setScreen("how")}
          onMute={toggleMute}
        />
      )}

      {screen === "how" && <HowTo onBack={() => setScreen("menu")} onStart={begin} />}

      {screen === "game" && !over && !upgrades && (
        <div className="pointer-events-none absolute right-4 top-24 z-30 flex flex-col items-end gap-2">
          <button
            type="button"
            tabIndex={-1}
            className="pointer-events-auto neon-panel rounded-full px-3 py-1.5 text-xs font-semibold tracking-[0.2em] text-cyan-200/80"
            onClick={toggleMute}
          >
            {muted ? "AUDIO OFF" : "AUDIO ON"}
          </button>
          <button
            type="button"
            tabIndex={-1}
            className="pointer-events-auto neon-panel rounded-full px-3 py-1.5 text-xs font-semibold tracking-[0.2em] text-cyan-200/80"
            onClick={() => gameRef.current?.togglePause()}
          >
            {paused ? "RESUME" : "PAUSE"}
          </button>
        </div>
      )}

      {touch && screen === "game" && !over && !upgrades && !paused && (
        <TouchControls
          onAxis={(x, y) => gameRef.current?.setAxis(x, y)}
          onDash={() => gameRef.current?.queueDash()}
        />
      )}

      {paused && !over && !upgrades && (
        <Overlay>
          <div className="neon-panel card-in w-[min(420px,92vw)] rounded-3xl p-10 text-center">
            <p className="font-display text-xs tracking-[0.5em] text-cyan-300/70">SYSTEM</p>
            <h2 className="font-display neon-title mt-2 text-4xl font-extrabold">PAUSED</h2>
            <p className="mt-3 text-sm text-white/60">The swarm is waiting.</p>
            <div className="mt-8 flex flex-col gap-3">
              <button
                className="neon-btn rounded-2xl bg-cyan-300 px-6 py-3 font-display text-sm font-bold tracking-[0.25em] text-[#041018]"
                onClick={() => gameRef.current?.togglePause()}
              >
                RESUME
              </button>
              <button
                className="neon-btn rounded-2xl border border-white/15 px-6 py-3 font-display text-sm tracking-[0.25em] text-white/70"
                onClick={() => {
                  setScreen("menu");
                  setBest(getBestScore());
                }}
              >
                ABORT RUN
              </button>
            </div>
          </div>
        </Overlay>
      )}

      {upgrades && !over && (
        <Overlay>
          <div className="card-in w-[min(980px,96vw)] px-4">
            <div className="mb-8 text-center">
              <p className="font-display text-xs tracking-[0.5em] text-amber-300/80">PROTOCOL SELECT</p>
              <h2 className="font-display neon-title mt-2 text-3xl font-extrabold md:text-5xl">EVOLVE</h2>
              <p className="mt-2 text-sm text-white/55">Choose one system upgrade · 1 / 2 / 3</p>
            </div>
            <div className="grid gap-4 md:grid-cols-3">
              {upgrades.map((u, i) => (
                <button
                  key={u.id}
                  onClick={() => pick(u.id)}
                  className={`neon-btn card-in rounded-3xl border bg-gradient-to-b p-6 text-left ${rarityTint[u.rarity]}`}
                  style={{ animationDelay: `${i * 80}ms` }}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-3xl">{u.glyph}</span>
                    <span className={`font-display text-[10px] tracking-[0.35em] uppercase ${rarityText[u.rarity]}`}>
                      {u.rarity} · {i + 1}
                    </span>
                  </div>
                  <h3 className="font-display mt-5 text-xl font-bold">{u.name}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-white/65">{u.desc}</p>
                </button>
              ))}
            </div>
          </div>
        </Overlay>
      )}

      {over && (
        <Overlay>
          <div className="neon-panel card-in w-[min(460px,92vw)] rounded-3xl p-10 text-center">
            <p className="font-display text-xs tracking-[0.5em] text-fuchsia-300/80">SIGNAL LOST</p>
            <h2 className="font-display neon-title mt-2 text-4xl font-extrabold">CORE BREACH</h2>
            <p className="mt-2 font-display text-3xl text-cyan-300">{over.score.toLocaleString()}</p>
            {over.score >= over.best && over.score > 0 && (
              <p className="mt-1 text-xs tracking-[0.3em] text-amber-300">NEW BEST</p>
            )}
            <div className="mt-6 grid grid-cols-2 gap-3 text-left text-sm">
              <Stat label="Wave" value={String(over.wave)} />
              <Stat label="Kills" value={String(over.kills)} />
              <Stat label="Time" value={formatTime(over.time)} />
              <Stat label="Level" value={String(over.level)} />
              <Stat label="Best combo" value={`x${over.comboMax}`} />
              <Stat label="Best score" value={over.best.toLocaleString()} />
            </div>
            <div className="mt-8 flex flex-col gap-3">
              <button
                className="neon-btn rounded-2xl bg-cyan-300 px-6 py-3 font-display text-sm font-bold tracking-[0.25em] text-[#041018]"
                onClick={begin}
              >
                REBOOT
              </button>
              <button
                className="neon-btn rounded-2xl border border-white/15 px-6 py-3 font-display text-sm tracking-[0.25em] text-white/70"
                onClick={() => {
                  setScreen("menu");
                  setOver(null);
                  setBest(getBestScore());
                }}
              >
                MAINFRAME
              </button>
            </div>
          </div>
        </Overlay>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3">
      <div className="text-[10px] tracking-[0.28em] text-white/40 uppercase">{label}</div>
      <div className="font-display mt-1 text-lg text-cyan-100">{value}</div>
    </div>
  );
}

function Overlay({ children }: { children: ReactNode }) {
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-[#05010d]/55 backdrop-blur-sm">
      {children}
    </div>
  );
}

function Menu({
  best,
  muted,
  onStart,
  onHow,
  onMute,
}: {
  best: number;
  muted: boolean;
  onStart: () => void;
  onHow: () => void;
  onMute: () => void;
}) {
  return (
    <div className="absolute inset-0 z-30">
      <img
        src={titleBg}
        alt=""
        className="absolute inset-0 h-full w-full object-cover opacity-80"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#05010d]/40 via-[#05010d]/55 to-[#05010d]" />
      <div
        className="pointer-events-none absolute inset-0 opacity-40"
        style={{
          backgroundImage:
            "linear-gradient(rgba(110,246,255,0.07) 1px, transparent 1px), linear-gradient(90deg, rgba(110,246,255,0.07) 1px, transparent 1px)",
          backgroundSize: "56px 56px",
          maskImage: "radial-gradient(ellipse at center, black 10%, transparent 72%)",
          WebkitMaskImage: "radial-gradient(ellipse at center, black 10%, transparent 72%)",
        }}
      />
      <div className="absolute -left-24 top-10 h-72 w-72 rounded-full bg-cyan-400/20 blur-3xl" />
      <div className="absolute right-0 bottom-10 h-80 w-80 rounded-full bg-fuchsia-500/20 blur-3xl" />

      <div className="relative flex h-full flex-col items-center justify-center px-6">
        <div className="mb-8 text-center" style={{ animation: "float-slow 6s ease-in-out infinite" }}>
          <p className="font-display text-[11px] tracking-[0.7em] text-cyan-300/80">NEON ARENA SURVIVAL</p>
          <h1
            className="font-display neon-title mt-3 text-6xl font-black leading-none tracking-[0.18em] md:text-8xl"
            style={{ animation: "flicker 4.5s infinite" }}
          >
            PULSAR
          </h1>
          <p className="mx-auto mt-5 max-w-md text-sm text-white/60 md:text-base">
            Break the swarm. Evolve your arsenal. Hold the grid until the void blinks first.
          </p>
        </div>

        <div className="flex w-full max-w-sm flex-col gap-3">
          <button
            onClick={onStart}
            className="neon-btn rounded-2xl bg-cyan-300 px-6 py-4 font-display text-sm font-bold tracking-[0.35em] text-[#041018] shadow-[0_0_40px_rgba(110,246,255,0.35)]"
          >
            INITIATE
          </button>
          <button
            onClick={onHow}
            className="neon-btn neon-panel rounded-2xl px-6 py-3 font-display text-sm tracking-[0.3em] text-cyan-100"
          >
            BRIEFING
          </button>
          <button
            onClick={onMute}
            className="neon-btn rounded-2xl border border-white/10 px-6 py-3 font-display text-xs tracking-[0.3em] text-white/55"
          >
            {muted ? "AUDIO DISABLED" : "AUDIO ENABLED"}
          </button>
        </div>

        <div className="mt-10 font-display text-xs tracking-[0.4em] text-white/40">
          BEST SIGNAL {best.toLocaleString().padStart(6, "0")}
        </div>
        <p className="mt-6 text-[11px] tracking-[0.25em] text-white/30">
          WASD MOVE · MOUSE AIM · SPACE DASH · AUTO-FIRE
        </p>
      </div>
    </div>
  );
}

function HowTo({ onBack, onStart }: { onBack: () => void; onStart: () => void }) {
  const rows = [
    ["WASD / Arrows", "Pilot the core through the grid"],
    ["Mouse", "Aim the pulse cannon"],
    ["Space / Shift / RMB", "Dash with brief invulnerability"],
    ["P / Esc", "Pause the simulation"],
    ["Survive waves", "Collect prism shards, level up, evolve"],
    ["Boss every 5", "Hex, Serpent, then the Core"],
  ];
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-[#05010d]">
      <img src={nebulaBg} alt="" className="absolute inset-0 h-full w-full object-cover opacity-40" />
      <div className="absolute inset-0 bg-[#05010d]/70" />
      <div className="relative neon-panel card-in w-[min(560px,92vw)] rounded-3xl p-8 md:p-10">
        <p className="font-display text-xs tracking-[0.5em] text-cyan-300/70">BRIEFING</p>
        <h2 className="font-display neon-title mt-2 text-3xl font-extrabold">HOW TO HOLD</h2>
        <div className="mt-6 space-y-3">
          {rows.map(([k, v]) => (
            <div key={k} className="flex items-start justify-between gap-6 border-b border-white/10 py-2 text-sm">
              <span className="font-display text-cyan-200">{k}</span>
              <span className="text-right text-white/60">{v}</span>
            </div>
          ))}
        </div>
        <div className="mt-8 flex gap-3">
          <button
            onClick={onBack}
            className="neon-btn flex-1 rounded-2xl border border-white/15 py-3 font-display text-xs tracking-[0.25em]"
          >
            BACK
          </button>
          <button
            onClick={onStart}
            className="neon-btn flex-1 rounded-2xl bg-cyan-300 py-3 font-display text-xs font-bold tracking-[0.25em] text-[#041018]"
          >
            INITIATE
          </button>
        </div>
      </div>
    </div>
  );
}

function TouchControls({
  onAxis,
  onDash,
}: {
  onAxis: (x: number, y: number) => void;
  onDash: () => void;
}) {
  const origin = useRef<{ x: number; y: number } | null>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });

  const move = (clientX: number, clientY: number) => {
    if (!origin.current) return;
    const dx = clientX - origin.current.x;
    const dy = clientY - origin.current.y;
    const max = 46;
    const len = Math.hypot(dx, dy);
    const s = len > max ? max / len : 1;
    const x = dx * s;
    const y = dy * s;
    setKnob({ x, y });
    onAxis(x / max, y / max);
  };

  return (
    <div className="absolute inset-x-0 bottom-0 z-30 flex items-end justify-between p-6 pointer-events-none">
      <div
        className="pointer-events-auto relative h-32 w-32 rounded-full border border-cyan-300/25 bg-cyan-300/5"
        onPointerDown={(e) => {
          origin.current = { x: e.clientX, y: e.clientY };
          (e.target as HTMLElement).setPointerCapture(e.pointerId);
        }}
        onPointerMove={(e) => move(e.clientX, e.clientY)}
        onPointerUp={() => {
          origin.current = null;
          setKnob({ x: 0, y: 0 });
          onAxis(0, 0);
        }}
      >
        <div
          className="absolute left-1/2 top-1/2 h-14 w-14 -translate-x-1/2 -translate-y-1/2 rounded-full bg-cyan-300/80 shadow-[0_0_20px_rgba(110,246,255,0.6)]"
          style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
        />
      </div>
      <button
        className="pointer-events-auto h-20 w-20 rounded-full border border-fuchsia-400/40 bg-fuchsia-500/20 font-display text-xs tracking-[0.2em] text-fuchsia-100"
        onPointerDown={(e) => {
          e.preventDefault();
          onDash();
        }}
      >
        DASH
      </button>
    </div>
  );
}
