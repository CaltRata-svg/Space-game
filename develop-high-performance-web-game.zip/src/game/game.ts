import { AudioEngine } from "./audio";
import nebulaSrc from "../assets/nebula.jpg";

const TAU = Math.PI * 2;
const BEST_KEY = "pulsar-best";

export type Rarity = "common" | "rare" | "epic";

export type UpgradeDef = {
  id: string;
  name: string;
  desc: string;
  max: number;
  weight: number;
  rarity: Rarity;
  glyph: string;
};

export type GameStats = {
  score: number;
  wave: number;
  kills: number;
  time: number;
  level: number;
  comboMax: number;
  best: number;
};

export type GameHooks = {
  onUpgrade: (choices: UpgradeDef[]) => void;
  onGameOver: (stats: GameStats) => void;
  onPause: (paused: boolean) => void;
};

export const UPGRADES: UpgradeDef[] = [
  { id: "pulse", name: "Pulse Cannon", desc: "+18% shot damage and velocity", max: 5, weight: 8, rarity: "common", glyph: "◈" },
  { id: "fork", name: "Forked Fire", desc: "Fire extra projectiles in a spread", max: 5, weight: 6, rarity: "rare", glyph: "⋔" },
  { id: "nova", name: "Nova Pulse", desc: "Periodic shockwave that shreds nearby foes", max: 4, weight: 5, rarity: "rare", glyph: "✸" },
  { id: "orbit", name: "Orbit Halo", desc: "Spinning blades that carve anything close", max: 4, weight: 5, rarity: "rare", glyph: "◉" },
  { id: "storm", name: "Storm Coil", desc: "Hits chain lightning to nearby enemies", max: 4, weight: 4, rarity: "epic", glyph: "↯" },
  { id: "drone", name: "Wisp Drone", desc: "A companion that hunts with you", max: 3, weight: 4, rarity: "epic", glyph: "✧" },
  { id: "seek", name: "Seekers", desc: "Shots curve toward the nearest target", max: 3, weight: 4, rarity: "rare", glyph: "⤷" },
  { id: "speed", name: "Afterburners", desc: "+12% move speed and tighter handling", max: 5, weight: 7, rarity: "common", glyph: "»" },
  { id: "hull", name: "Titanium Hull", desc: "+25 max hull integrity", max: 5, weight: 7, rarity: "common", glyph: "▣" },
  { id: "magnet", name: "Gravity Well", desc: "Pull prism shards from farther away", max: 5, weight: 7, rarity: "common", glyph: "◎" },
  { id: "rate", name: "Overclock", desc: "+14% fire rate across all systems", max: 5, weight: 7, rarity: "common", glyph: "⚡" },
  { id: "caliber", name: "Heavy Caliber", desc: "+16% global damage", max: 5, weight: 6, rarity: "common", glyph: "●" },
  { id: "area", name: "Expansion", desc: "Larger bullets, novas and orbit radius", max: 4, weight: 5, rarity: "rare", glyph: "◯" },
  { id: "pierce", name: "Piercing Rounds", desc: "Shots pass through additional targets", max: 4, weight: 5, rarity: "rare", glyph: "⇉" },
  { id: "regen", name: "Second Wind", desc: "Slowly regenerate hull over time", max: 3, weight: 4, rarity: "rare", glyph: "✚" },
  { id: "crit", name: "Critical Matrix", desc: "+8% crit chance, crits deal 2.4x", max: 4, weight: 5, rarity: "rare", glyph: "★" },
  { id: "dash", name: "Kinetic Dash", desc: "Faster dash recharge; dash damages foes", max: 3, weight: 5, rarity: "rare", glyph: "➤" },
  { id: "aegis", name: "Aegis Field", desc: "A regenerating energy shield", max: 3, weight: 4, rarity: "epic", glyph: "⬡" },
  { id: "luck", name: "Fortune", desc: "More shard value and luckier drops", max: 4, weight: 5, rarity: "common", glyph: "♣" },
];

export function getBestScore() {
  try {
    return Number(localStorage.getItem(BEST_KEY) || 0);
  } catch {
    return 0;
  }
}

type EnemyKind =
  | "wisp"
  | "dart"
  | "tank"
  | "splitter"
  | "orbiter"
  | "sniper"
  | "swarm"
  | "bomber"
  | "elite"
  | "hexboss"
  | "serpent"
  | "coreboss";

type Enemy = {
  alive: boolean;
  kind: EnemyKind;
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  hp: number;
  maxHp: number;
  dmg: number;
  speed: number;
  angle: number;
  t: number;
  state: number;
  worth: number;
  xp: number;
  gen: number;
  flash: number;
  freeze: number;
  teleX: number;
  teleY: number;
  spin: number;
  segs: { x: number; y: number }[] | null;
  contactCd: number;
};

type Bullet = {
  alive: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  dmg: number;
  life: number;
  team: 0 | 1;
  pierce: number;
  homing: number;
  cr: number;
  cg: number;
  cb: number;
};

type Gem = {
  alive: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  v: number;
  r: number;
  t: number;
};

type Particle = {
  alive: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  growth: number;
  cr: number;
  cg: number;
  cb: number;
  kind: 0 | 1 | 2 | 3;
  rot: number;
  rv: number;
  drag: number;
};

type Floater = {
  alive: boolean;
  x: number;
  y: number;
  vy: number;
  text: string;
  life: number;
  max: number;
  cr: number;
  cg: number;
  cb: number;
  size: number;
};

type Bolt = { x1: number; y1: number; x2: number; y2: number; life: number };

type Star = { x: number; y: number; z: number; r: number; tw: number };

const rand = (a = 0, b = 1) => a + Math.random() * (b - a);
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const hypot = Math.hypot;
const atan2 = Math.atan2;
const cos = Math.cos;
const sin = Math.sin;

function hexRgb(h: string): [number, number, number] {
  const n = parseInt(h.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function poly(ctx: CanvasRenderingContext2D, n: number, r: number, rot: number) {
  ctx.beginPath();
  for (let i = 0; i < n; i++) {
    const a = rot + (i * TAU) / n - Math.PI / 2;
    const x = cos(a) * r;
    const y = sin(a) * r;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
}

export class Game {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private hooks: GameHooks;
  private audio = new AudioEngine();
  private raf = 0;
  private unbind: Array<() => void> = [];
  private last = 0;
  private w = 1;
  private h = 1;
  private dpr = 1;
  private nebula = new Image();
  private stars: Star[] = [];

  private keys = new Set<string>();
  private ptrX = 0;
  private ptrY = 0;
  private axisX = 0;
  private axisY = 0;
  private dashQueued = false;

  paused = false;
  awaitingUpgrade = false;
  muted = false;
  autoAim = false;
  private dead = false;
  private deadT = 0;
  private ended = false;
  private started = false;

  private camX = 0;
  private camY = 0;
  private shake = 0;
  private flash = 0;
  private hitstop = 0;
  private timeScale = 1;
  private vignette = 0;

  private px = 0;
  private py = 0;
  private pvx = 0;
  private pvy = 0;
  private pang = 0;
  private pr = 13;
  private hp = 100;
  private maxHp = 100;
  private shield = 0;
  private maxShield = 0;
  private invuln = 0;
  private dashT = 0;
  private dashCd = 0;
  private dashMax = 1.05;
  private fireCd = 0;
  private novaCd = 0;
  private drone = { x: 0, y: 0, cd: 0, a: 0 };
  private ghosts: { x: number; y: number; a: number; life: number }[] = [];
  private trail: { x: number; y: number }[] = [];

  private lv = 1;
  private xp = 0;
  private xpNeed = 40;
  private score = 0;
  private kills = 0;
  private time = 0;
  private combo = 0;
  private comboT = 0;
  private comboMax = 0;
  private wave = 0;
  private waveLeft = 0;
  private spawnQ: { kind: EnemyKind; wait: number }[] = [];
  private restT = 0;
  private banner = { text: "", sub: "", t: 0, col: "#6ef6ff" };
  private levels: Record<string, number> = {};
  private choices: UpgradeDef[] = [];

  private enemies: Enemy[] = [];
  private bullets: Bullet[] = [];
  private gems: Gem[] = [];
  private parts: Particle[] = [];
  private floats: Floater[] = [];
  private bolts: Bolt[] = [];

  constructor(canvas: HTMLCanvasElement, hooks: GameHooks) {
    this.canvas = canvas;
    const ctx = canvas.getContext("2d", { alpha: false, desynchronized: true });
    if (!ctx) throw new Error("No 2D context");
    this.ctx = ctx;
    this.hooks = hooks;
    this.nebula.src = nebulaSrc;
    this.stars = Array.from({ length: 160 }, () => ({
      x: Math.random(),
      y: Math.random(),
      z: rand(0.15, 0.9),
      r: rand(0.4, 1.8),
      tw: rand(0, TAU),
    }));
    for (const u of UPGRADES) this.levels[u.id] = 0;
  }

  async start() {
    this.bind();
    this.resize();
    await this.audio.ensure();
    this.audio.startMusic();
    this.reset();
    this.started = true;
    this.last = performance.now();
    this.loop(this.last);
  }

  destroy() {
    this.started = false;
    cancelAnimationFrame(this.raf);
    this.unbind.forEach((f) => f());
    this.unbind = [];
    this.audio.destroy();
  }

  setMuted(muted: boolean) {
    this.muted = muted;
    this.audio.setMuted(muted);
  }

  setAxis(x: number, y: number) {
    this.axisX = x;
    this.axisY = y;
  }

  queueDash() {
    this.dashQueued = true;
  }

  togglePause() {
    if (this.dead || this.awaitingUpgrade) return;
    this.paused = !this.paused;
    this.hooks.onPause(this.paused);
  }

  chooseUpgrade(id: string) {
    const def = UPGRADES.find((u) => u.id === id);
    if (!def) return;
    this.levels[id] = (this.levels[id] || 0) + 1;
    this.apply(id);
    this.audio.select();
    this.awaitingUpgrade = false;
    this.choices = [];
    if (this.xp >= this.xpNeed) this.levelUp();
  }

  restart() {
    this.ended = false;
    this.reset();
  }

  private reset() {
    this.dead = false;
    this.deadT = 0;
    this.ended = false;
    this.paused = false;
    this.awaitingUpgrade = false;
    this.px = 0;
    this.py = 0;
    this.pvx = 0;
    this.pvy = 0;
    this.pang = 0;
    this.maxHp = 100;
    this.hp = 100;
    this.shield = 0;
    this.maxShield = 0;
    this.invuln = 1;
    this.dashT = 0;
    this.dashCd = 0;
    this.fireCd = 0;
    this.novaCd = 1.2;
    this.drone.x = -40;
    this.drone.y = 20;
    this.ghosts.length = 0;
    this.trail.length = 0;
    this.lv = 1;
    this.xp = 0;
    this.xpNeed = 40;
    this.score = 0;
    this.kills = 0;
    this.time = 0;
    this.combo = 0;
    this.comboT = 0;
    this.comboMax = 0;
    this.wave = 0;
    this.waveLeft = 0;
    this.spawnQ.length = 0;
    this.restT = 0.6;
    this.camX = 0;
    this.camY = 0;
    this.shake = 0;
    this.flash = 0;
    this.hitstop = 0;
    this.timeScale = 1;
    this.choices = [];
    for (const u of UPGRADES) this.levels[u.id] = 0;
    for (const e of this.enemies) e.alive = false;
    for (const b of this.bullets) b.alive = false;
    for (const g of this.gems) g.alive = false;
    for (const p of this.parts) p.alive = false;
    for (const f of this.floats) f.alive = false;
    this.bolts.length = 0;
    this.banner = { text: "PULSAR", sub: "hold the grid", t: 2.2, col: "#6ef6ff" };
    for (let i = 0; i < 40; i++) {
      this.burst(rand(-200, 200), rand(-120, 120), 110, 246, 255, 6, 80);
    }
  }

  private apply(id: string) {
    if (id === "hull") {
      this.maxHp += 25;
      this.hp += 25;
    }
    if (id === "aegis") {
      this.maxShield += 28;
      this.shield = this.maxShield;
    }
  }

  private lvOf(id: string) {
    return this.levels[id] || 0;
  }

  private dmgMul() {
    return (1 + this.lvOf("caliber") * 0.16) * (1 + this.lvOf("pulse") * 0.18);
  }

  private areaMul() {
    return 1 + this.lvOf("area") * 0.16;
  }

  private bind() {
    const onKey = (e: KeyboardEvent) => {
      if (e.repeat) {
        this.keys.add(e.code);
        return;
      }
      if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) e.preventDefault();
      this.keys.add(e.code);
      if (e.code === "Escape" || e.code === "KeyP") this.togglePause();
      if (e.code === "Space" || e.code === "ShiftLeft" || e.code === "ShiftRight") this.dashQueued = true;
      if (this.awaitingUpgrade && (e.code === "Digit1" || e.code === "Digit2" || e.code === "Digit3")) {
        const i = Number(e.code.slice(5)) - 1;
        if (this.choices[i]) this.chooseUpgrade(this.choices[i].id);
      }
    };
    const onUp = (e: KeyboardEvent) => this.keys.delete(e.code);
    const onMove = (e: PointerEvent) => {
      const r = this.canvas.getBoundingClientRect();
      this.ptrX = e.clientX - r.left;
      this.ptrY = e.clientY - r.top;
    };
    const onDown = (e: PointerEvent) => {
      if (e.button === 2) {
        e.preventDefault();
        this.dashQueued = true;
      }
    };
    const onCtx = (e: Event) => e.preventDefault();
    const onBlur = () => this.keys.clear();
    const onResize = () => this.resize();
    window.addEventListener("keydown", onKey);
    window.addEventListener("keyup", onUp);
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerdown", onDown);
    window.addEventListener("blur", onBlur);
    window.addEventListener("resize", onResize);
    this.canvas.addEventListener("contextmenu", onCtx);
    this.unbind.push(() => window.removeEventListener("keydown", onKey));
    this.unbind.push(() => window.removeEventListener("keyup", onUp));
    this.unbind.push(() => window.removeEventListener("pointermove", onMove));
    this.unbind.push(() => window.removeEventListener("pointerdown", onDown));
    this.unbind.push(() => window.removeEventListener("blur", onBlur));
    this.unbind.push(() => window.removeEventListener("resize", onResize));
    this.unbind.push(() => this.canvas.removeEventListener("contextmenu", onCtx));
  }

  private resize() {
    const r = this.canvas.getBoundingClientRect();
    this.w = Math.max(1, r.width);
    this.h = Math.max(1, r.height);
    this.dpr = Math.min(2, window.devicePixelRatio || 1);
    this.canvas.width = Math.floor(this.w * this.dpr);
    this.canvas.height = Math.floor(this.h * this.dpr);
    if (this.ptrX === 0 && this.ptrY === 0) {
      this.ptrX = this.w * 0.5;
      this.ptrY = this.h * 0.42;
    }
  }

  private loop = (now: number) => {
    if (!this.started) return;
    const raw = Math.min(0.033, (now - this.last) / 1000);
    this.last = now;
    if (!this.paused && !this.awaitingUpgrade) this.update(raw);
    this.draw(now);
    this.raf = requestAnimationFrame(this.loop);
  };

  private update(raw: number) {
    if (this.hitstop > 0) {
      this.hitstop -= raw;
      this.shake *= 0.86;
      this.updateFx(raw);
      return;
    }
    const dt = raw * this.timeScale;
    this.time += dt;
    this.audio.intensity = clamp(this.wave / 16, 0, 1);
    this.timeScale = lerp(this.timeScale, this.dead ? 0.35 : 1, 1 - Math.pow(0.02, dt * 60));
    this.shake *= Math.pow(0.88, dt * 60);
    this.flash *= Math.pow(0.9, dt * 60);
    this.invuln = Math.max(0, this.invuln - dt);
    this.comboT -= dt;
    if (this.comboT <= 0) this.combo = 0;
    this.banner.t = Math.max(0, this.banner.t - dt);
    if (this.dead) {
      this.deadT += dt;
      this.updateFx(dt);
      this.updateBullets(dt);
      this.updateEnemies(dt);
      if (this.deadT > 1.35) this.finish();
      return;
    }

    this.updatePlayer(dt);
    this.updateWeapons(dt);
    this.updateWave(dt);
    this.updateEnemies(dt);
    this.updateBullets(dt);
    this.updateGems(dt);
    this.updateFx(dt);
    this.collide();

    const lookX = this.worldMX() - this.px;
    const lookY = this.worldMY() - this.py;
    const targetCamX = this.px + lookX * 0.12;
    const targetCamY = this.py + lookY * 0.12;
    this.camX = lerp(this.camX, targetCamX, 1 - Math.pow(0.002, dt * 60));
    this.camY = lerp(this.camY, targetCamY, 1 - Math.pow(0.002, dt * 60));
    this.vignette = lerp(this.vignette, this.hp < 30 ? 1 : 0, 1 - Math.pow(0.08, dt * 60));
  }

  private worldMX() {
    return this.camX + (this.ptrX - this.w / 2);
  }
  private worldMY() {
    return this.camY + (this.ptrY - this.h / 2);
  }

  private updatePlayer(dt: number) {
    let ix = this.axisX;
    let iy = this.axisY;
    if (this.keys.has("KeyW") || this.keys.has("ArrowUp")) iy -= 1;
    if (this.keys.has("KeyS") || this.keys.has("ArrowDown")) iy += 1;
    if (this.keys.has("KeyA") || this.keys.has("ArrowLeft")) ix -= 1;
    if (this.keys.has("KeyD") || this.keys.has("ArrowRight")) ix += 1;
    const il = hypot(ix, iy);
    if (il > 1) {
      ix /= il;
      iy /= il;
    }
    const spd = 275 * (1 + this.lvOf("speed") * 0.12);
    const accel = 2400;
    this.pvx += ix * accel * dt;
    this.pvy += iy * accel * dt;
    this.pvx *= Math.pow(0.0018, dt);
    this.pvy *= Math.pow(0.0018, dt);
    const sl = hypot(this.pvx, this.pvy);
    if (sl > spd && this.dashT <= 0) {
      this.pvx = (this.pvx / sl) * spd;
      this.pvy = (this.pvy / sl) * spd;
    }

    this.dashCd = Math.max(0, this.dashCd - dt);
    if (this.dashQueued && this.dashCd <= 0) {
      let dx = ix;
      let dy = iy;
      if (hypot(dx, dy) < 0.1) {
        dx = cos(this.pang);
        dy = sin(this.pang);
      }
      const dl = hypot(dx, dy) || 1;
      const boost = 780;
      this.pvx = (dx / dl) * boost;
      this.pvy = (dy / dl) * boost;
      this.dashT = 0.16;
      this.dashCd = this.dashMax * (1 - this.lvOf("dash") * 0.18);
      this.invuln = Math.max(this.invuln, 0.2);
      this.audio.dash();
      this.burst(this.px, this.py, 110, 246, 255, 18, 260);
      if (this.lvOf("dash") > 0) this.dashDamage();
    }
    this.dashQueued = false;
    if (this.dashT > 0) {
      this.dashT -= dt;
      this.ghosts.push({ x: this.px, y: this.py, a: this.pang, life: 0.22 });
    }

    this.px += this.pvx * dt;
    this.py += this.pvy * dt;
    if (il > 0.25 || this.dashT > 0) {
      const p = this.allocP();
      if (p) {
        const back = this.pang + Math.PI + rand(-0.35, 0.35);
        p.alive = true;
        p.x = this.px + cos(back) * 12;
        p.y = this.py + sin(back) * 12;
        p.vx = cos(back) * rand(40, 140);
        p.vy = sin(back) * rand(40, 140);
        p.max = rand(0.12, 0.28);
        p.life = p.max;
        p.size = rand(1.2, 2.8);
        p.growth = -6;
        p.cr = this.dashT > 0 ? 255 : 110;
        p.cg = this.dashT > 0 ? 80 : 246;
        p.cb = this.dashT > 0 ? 180 : 255;
        p.kind = 0;
        p.rot = 0;
        p.rv = 0;
        p.drag = 0.9;
      }
    }
    if (this.autoAim) {
      const tgt = this.nearest(this.px, this.py, 920);
      this.pang = tgt ? atan2(tgt.y - this.py, tgt.x - this.px) : this.pang;
    } else {
      this.pang = atan2(this.worldMY() - this.py, this.worldMX() - this.px);
    }

    this.trail.push({ x: this.px, y: this.py });
    if (this.trail.length > 14) this.trail.shift();
    for (const g of this.ghosts) g.life -= dt;
    this.ghosts = this.ghosts.filter((g) => g.life > 0);

    if (this.lvOf("regen") && this.hp < this.maxHp) {
      this.hp = Math.min(this.maxHp, this.hp + dt * (2.2 * this.lvOf("regen")));
    }
    if (this.maxShield > 0) {
      this.shield = Math.min(this.maxShield, this.shield + dt * (6 + this.lvOf("aegis") * 3));
    }
  }

  private dashDamage() {
    const r = 46 * this.areaMul();
    const dmg = 18 * this.dmgMul() * (1 + this.lvOf("dash") * 0.4);
    for (const e of this.enemies) {
      if (!e.alive) continue;
      if (hypot(e.x - this.px, e.y - this.py) < r + e.r) this.hurtEnemy(e, dmg, false);
    }
    this.ring(this.px, this.py, 110, 246, 255, 38);
  }

  private updateWeapons(dt: number) {
    const rate = 1 + this.lvOf("rate") * 0.14;
    this.fireCd -= dt;
    if (this.fireCd <= 0) {
      this.fireCd = 0.165 / rate;
      this.firePulse();
    }
    if (this.lvOf("nova") > 0) {
      this.novaCd -= dt;
      if (this.novaCd <= 0) {
        this.novaCd = 2.4 / (1 + this.lvOf("nova") * 0.12);
        this.fireNova();
      }
    }
    if (this.lvOf("drone") > 0) {
      const tx = this.px - cos(this.pang) * 42 + sin(this.pang) * 28;
      const ty = this.py - sin(this.pang) * 42 - cos(this.pang) * 28;
      this.drone.x = lerp(this.drone.x, tx, 1 - Math.pow(0.08, dt * 60));
      this.drone.y = lerp(this.drone.y, ty, 1 - Math.pow(0.08, dt * 60));
      this.drone.cd -= dt;
      const tgt = this.nearest(this.drone.x, this.drone.y, 420);
      if (tgt) this.drone.a = atan2(tgt.y - this.drone.y, tgt.x - this.drone.x);
      if (this.drone.cd <= 0 && tgt) {
        this.drone.cd = 0.28 / rate;
        const n = this.lvOf("drone");
        for (let i = 0; i < n; i++) {
          const spr = (i - (n - 1) / 2) * 0.16;
          this.spawnBullet(this.drone.x, this.drone.y, this.drone.a + spr, 620, 9 * this.dmgMul(), 0, 4.2, 0, 200, 255, 180);
        }
      }
    }
  }

  private firePulse() {
    const forks = this.lvOf("fork");
    const count = 1 + forks;
    const spread = 0.13 + forks * 0.04;
    const spd = 640 + this.lvOf("pulse") * 40;
    const dmg = 11 * this.dmgMul();
    const pierce = this.lvOf("pierce");
    const size = 4.2 * this.areaMul();
    const homing = this.lvOf("seek") * 4.2;
    for (let i = 0; i < count; i++) {
      const a = this.pang + (i - (count - 1) / 2) * spread;
      this.spawnBullet(this.px + cos(a) * 16, this.py + sin(a) * 16, a, spd, dmg, pierce, size, 0, 180, 255, 255, homing);
    }
    this.audio.shoot();
  }

  private fireNova() {
    const n = 10 + this.lvOf("nova") * 4;
    const dmg = 14 * this.dmgMul() * (1 + this.lvOf("nova") * 0.2);
    const r = 88 * this.areaMul() * (1 + this.lvOf("nova") * 0.12);
    this.ring(this.px, this.py, 255, 80, 200, r);
    this.burst(this.px, this.py, 255, 90, 210, 22, 220);
    this.shake = Math.min(18, this.shake + 6);
    for (const e of this.enemies) {
      if (!e.alive) continue;
      if (hypot(e.x - this.px, e.y - this.py) < r + e.r) this.hurtEnemy(e, dmg, false);
    }
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU;
      this.spawnBullet(this.px, this.py, a, 420, dmg * 0.45, 0, 3.5 * this.areaMul(), 0, 255, 110, 220);
    }
  }

  private updateWave(dt: number) {
    if (this.spawnQ.length) {
      this.spawnQ[0].wait -= dt;
      if (this.spawnQ[0].wait <= 0) {
        const s = this.spawnQ.shift()!;
        this.spawnEnemy(s.kind);
        this.waveLeft = Math.max(0, this.waveLeft - 1);
      }
      return;
    }
    if (this.waveLeft > 0) return;
    const living = this.enemies.reduce((n, e) => n + (e.alive ? 1 : 0), 0);
    if (living > 0) return;
    this.restT -= dt;
    if (this.restT > 0) return;
    this.wave += 1;
    this.planWave(this.wave);
    this.restT = 1.6;
  }

  private planWave(w: number) {
    const q: { kind: EnemyKind; wait: number }[] = [];
    const push = (kind: EnemyKind, n: number, gap: number) => {
      for (let i = 0; i < n; i++) q.push({ kind, wait: i === 0 ? 0.05 : gap });
    };
    const boss = w % 5 === 0;
    if (boss) {
      this.audio.boss();
      this.shake = 16;
      if (w % 15 === 0) {
        this.banner = { text: "CORE SINGULARITY", sub: "wave " + w, t: 2.6, col: "#ffd166" };
        push("coreboss", 1, 0);
        push("elite", 2, 0.4);
      } else if (w % 10 === 0) {
        this.banner = { text: "SERPENT PROTOCOL", sub: "wave " + w, t: 2.6, col: "#ff3cac" };
        push("serpent", 1, 0);
        push("orbiter", 4, 0.3);
      } else {
        this.banner = { text: "HEX GUARDIAN", sub: "wave " + w, t: 2.6, col: "#6ef6ff" };
        push("hexboss", 1, 0);
        push("wisp", 8, 0.12);
      }
    } else {
      this.banner = { text: "WAVE " + w, sub: "break the swarm", t: 1.6, col: "#6ef6ff" };
      push("wisp", 6 + w * 2, 0.09);
      if (w >= 2) push("dart", 2 + w, 0.16);
      if (w >= 3) push("swarm", 10 + w * 3, 0.05);
      if (w >= 4) push("tank", Math.floor(1 + w / 2), 0.35);
      if (w >= 5) push("splitter", Math.max(1, w - 3), 0.28);
      if (w >= 6) push("orbiter", 1 + Math.floor(w / 3), 0.3);
      if (w >= 7) push("sniper", Math.floor(w / 4), 0.45);
      if (w >= 8) push("bomber", Math.max(1, Math.floor(w / 5)), 0.4);
      if (w >= 9) push("elite", 1 + Math.floor(w / 10), 0.6);
    }
    this.waveLeft = q.length;
    this.spawnQ = q;
  }

  private spawnEnemy(kind: EnemyKind, x?: number, y?: number, gen = 0) {
    let e = this.enemies.find((o) => !o.alive);
    if (!e) {
      e = this.makeEnemy();
      this.enemies.push(e);
    }
    const a = rand(0, TAU);
    const dist = Math.max(this.w, this.h) * 0.58 + rand(20, 90);
    e.alive = true;
    e.kind = kind;
    e.x = x ?? this.camX + cos(a) * dist;
    e.y = y ?? this.camY + sin(a) * dist;
    e.vx = 0;
    e.vy = 0;
    e.angle = rand(0, TAU);
    e.t = rand(0, 1);
    e.state = 0;
    e.gen = gen;
    e.flash = 0;
    e.freeze = 0;
    e.teleX = 0;
    e.teleY = 0;
    e.spin = 0;
    e.contactCd = 0;
    e.segs = null;
    const sc = 1 + this.wave * 0.085;
    switch (kind) {
      case "wisp":
        Object.assign(e, { r: 12, hp: 16 * sc, dmg: 8, speed: 86, worth: 10, xp: 4 });
        break;
      case "dart":
        Object.assign(e, { r: 11, hp: 14 * sc, dmg: 10, speed: 70, worth: 16, xp: 5 });
        break;
      case "tank":
        Object.assign(e, { r: 20, hp: 70 * sc, dmg: 14, speed: 48, worth: 40, xp: 12 });
        break;
      case "splitter":
        Object.assign(e, {
          r: gen ? 9 : 16,
          hp: (gen ? 10 : 28) * sc,
          dmg: 9,
          speed: gen ? 120 : 72,
          worth: gen ? 8 : 28,
          xp: gen ? 3 : 9,
        });
        break;
      case "orbiter":
        Object.assign(e, { r: 13, hp: 26 * sc, dmg: 11, speed: 150, worth: 22, xp: 7 });
        break;
      case "sniper":
        Object.assign(e, { r: 12, hp: 22 * sc, dmg: 8, speed: 78, worth: 30, xp: 10 });
        break;
      case "swarm":
        Object.assign(e, { r: 7, hp: 7 * sc, dmg: 6, speed: 130, worth: 6, xp: 2 });
        break;
      case "bomber":
        Object.assign(e, { r: 15, hp: 32 * sc, dmg: 18, speed: 95, worth: 34, xp: 11 });
        break;
      case "elite":
        Object.assign(e, { r: 18, hp: 90 * sc, dmg: 16, speed: 92, worth: 80, xp: 22 });
        break;
      case "hexboss":
        Object.assign(e, { r: 52, hp: 420 * sc, dmg: 22, speed: 70, worth: 600, xp: 80 });
        break;
      case "serpent":
        Object.assign(e, { r: 22, hp: 520 * sc, dmg: 18, speed: 170, worth: 800, xp: 100 });
        e.segs = Array.from({ length: 14 }, (_, i) => ({ x: e!.x - i * 22, y: e!.y }));
        break;
      case "coreboss":
        Object.assign(e, { r: 58, hp: 760 * sc, dmg: 24, speed: 55, worth: 1200, xp: 140 });
        break;
    }
    e.maxHp = e.hp;
  }

  private makeEnemy(): Enemy {
    return {
      alive: false,
      kind: "wisp",
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      r: 10,
      hp: 1,
      maxHp: 1,
      dmg: 8,
      speed: 80,
      angle: 0,
      t: 0,
      state: 0,
      worth: 1,
      xp: 1,
      gen: 0,
      flash: 0,
      freeze: 0,
      teleX: 0,
      teleY: 0,
      spin: 0,
      segs: null,
      contactCd: 0,
    };
  }

  private updateEnemies(dt: number) {
    for (const e of this.enemies) {
      if (!e.alive) continue;
      e.t += dt;
      e.flash = Math.max(0, e.flash - dt * 8);
      e.freeze = Math.max(0, e.freeze - dt);
      e.contactCd = Math.max(0, e.contactCd - dt);
      const frozen = e.freeze > 0 ? 0.45 : 1;
      const dx = this.px - e.x;
      const dy = this.py - e.y;
      const dist = hypot(dx, dy) || 1;
      const nx = dx / dist;
      const ny = dy / dist;
      switch (e.kind) {
        case "wisp":
        case "swarm":
        case "elite":
        case "splitter":
        case "tank": {
          e.vx += nx * e.speed * 3.2 * dt * frozen;
          e.vy += ny * e.speed * 3.2 * dt * frozen;
          const sp = hypot(e.vx, e.vy);
          const max = e.speed * frozen;
          if (sp > max) {
            e.vx = (e.vx / sp) * max;
            e.vy = (e.vy / sp) * max;
          }
          e.angle = atan2(e.vy, e.vx);
          if (e.kind === "tank" && e.t > 1.7) {
            e.t = 0;
            for (let i = -1; i <= 1; i++) this.spawnBullet(e.x, e.y, e.angle + i * 0.18, 280, 10, 0, 5, 1, 255, 140, 70);
          }
          if (e.kind === "elite" && e.t > 1.15) {
            e.t = 0;
            for (let i = 0; i < 8; i++) this.spawnBullet(e.x, e.y, e.angle + (i * TAU) / 8, 260, 9, 0, 4.5, 1, 255, 209, 102);
          }
          break;
        }
        case "dart": {
          if (e.state === 0) {
            e.vx *= Math.pow(0.05, dt);
            e.vy *= Math.pow(0.05, dt);
            if (e.t > 0.55) {
              e.state = 1;
              e.t = 0;
              e.vx = nx * 560 * frozen;
              e.vy = ny * 560 * frozen;
            }
          } else {
            if (e.t > 0.28) {
              e.state = 0;
              e.t = 0;
            }
          }
          e.angle = atan2(e.vy, e.vx);
          break;
        }
        case "orbiter": {
          const tx = -ny;
          const ty = nx;
          const side = e.gen % 2 === 0 ? 1 : -1;
          e.vx += (tx * side * 1.4 + nx * 0.35) * e.speed * dt * frozen;
          e.vy += (ty * side * 1.4 + ny * 0.35) * e.speed * dt * frozen;
          const sp = hypot(e.vx, e.vy);
          if (sp > e.speed * frozen) {
            e.vx = (e.vx / sp) * e.speed * frozen;
            e.vy = (e.vy / sp) * e.speed * frozen;
          }
          e.angle = atan2(e.vy, e.vx);
          break;
        }
        case "sniper": {
          if (dist < 300) {
            e.vx -= nx * 220 * dt;
            e.vy -= ny * 220 * dt;
          } else if (dist > 430) {
            e.vx += nx * 180 * dt;
            e.vy += ny * 180 * dt;
          } else {
            e.vx *= Math.pow(0.04, dt);
            e.vy *= Math.pow(0.04, dt);
          }
          const sp = hypot(e.vx, e.vy);
          if (sp > e.speed) {
            e.vx = (e.vx / sp) * e.speed;
            e.vy = (e.vy / sp) * e.speed;
          }
          e.angle = atan2(dy, dx);
          if (e.t > 1.35) {
            e.t = 0;
            this.spawnBullet(e.x, e.y, e.angle, 420, 12, 0, 5, 1, 255, 70, 90);
          }
          break;
        }
        case "bomber": {
          e.vx += nx * e.speed * 3 * dt;
          e.vy += ny * e.speed * 3 * dt;
          const sp = hypot(e.vx, e.vy);
          if (sp > e.speed) {
            e.vx = (e.vx / sp) * e.speed;
            e.vy = (e.vy / sp) * e.speed;
          }
          if (dist < 78) {
            e.state += dt;
            if (e.state > 0.42) this.detonate(e);
          } else e.state = Math.max(0, e.state - dt * 0.5);
          e.angle = atan2(e.vy, e.vx);
          break;
        }
        case "hexboss": {
          e.spin += dt * 1.4;
          e.angle = e.spin;
          if (e.state === 0) {
            e.vx += nx * 40 * dt;
            e.vy += ny * 40 * dt;
            if (e.t > 1.4) {
              e.t = 0;
              for (let i = 0; i < 16; i++) {
                this.spawnBullet(e.x, e.y, e.spin + (i * TAU) / 16, 240, 11, 0, 6, 1, 110, 246, 255);
              }
              if (Math.random() < 0.4) {
                e.state = 1;
                e.teleX = this.px;
                e.teleY = this.py;
              }
            }
          } else if (e.state === 1) {
            e.vx *= 0.9;
            e.vy *= 0.9;
            if (e.t > 0.45) {
              const a = atan2(e.teleY - e.y, e.teleX - e.x);
              e.vx = cos(a) * 520;
              e.vy = sin(a) * 520;
              e.state = 2;
              e.t = 0;
            }
          } else {
            if (e.t > 0.38) {
              e.state = 0;
              e.t = 0;
              if (Math.random() < 0.5) {
                for (let i = 0; i < 3; i++) this.spawnEnemy("wisp", e.x + rand(-20, 20), e.y + rand(-20, 20));
              }
            }
          }
          const sp = hypot(e.vx, e.vy);
          if (sp > 520) {
            e.vx = (e.vx / sp) * 520;
            e.vy = (e.vy / sp) * 520;
          }
          break;
        }
        case "serpent": {
          const desired = atan2(dy, dx);
          let diff = desired - e.angle;
          while (diff > Math.PI) diff -= TAU;
          while (diff < -Math.PI) diff += TAU;
          e.angle += clamp(diff, -2.6 * dt * frozen, 2.6 * dt * frozen);
          e.vx = cos(e.angle) * e.speed * frozen;
          e.vy = sin(e.angle) * e.speed * frozen;
          if (e.t > 1.8) {
            e.t = 0;
            this.spawnBullet(e.x, e.y, e.angle, 340, 12, 0, 6, 1, 255, 60, 172);
          }
          if (e.segs) {
            let px = e.x;
            let py = e.y;
            for (const s of e.segs) {
              const ddx = px - s.x;
              const ddy = py - s.y;
              const d = hypot(ddx, ddy) || 1;
              const spacing = 20;
              s.x = px - (ddx / d) * spacing;
              s.y = py - (ddy / d) * spacing;
              px = s.x;
              py = s.y;
            }
          }
          break;
        }
        case "coreboss": {
          e.spin += dt * (1.8 + (1 - e.hp / e.maxHp) * 2);
          e.angle = e.spin;
          e.vx += nx * 28 * dt;
          e.vy += ny * 28 * dt;
          const sp = hypot(e.vx, e.vy);
          if (sp > e.speed) {
            e.vx = (e.vx / sp) * e.speed;
            e.vy = (e.vy / sp) * e.speed;
          }
          if (e.t > 0.09) {
            e.t = 0;
            this.spawnBullet(e.x, e.y, e.spin, 270, 10, 0, 5, 1, 255, 209, 102);
            this.spawnBullet(e.x, e.y, e.spin + Math.PI, 270, 10, 0, 5, 1, 255, 60, 172);
          }
          if (Math.floor(e.t * 10) === 0 && Math.random() < 0.01) {
            this.ring(e.x, e.y, 255, 209, 102, 70);
          }
          break;
        }
      }
      e.x += e.vx * dt;
      e.y += e.vy * dt;
    }
  }

  private detonate(e: Enemy) {
    e.alive = false;
    this.burst(e.x, e.y, 255, 90, 80, 36, 280);
    this.ring(e.x, e.y, 255, 80, 70, 70);
    this.shake = Math.min(22, this.shake + 10);
    this.audio.explode(1.2);
    const r = 96;
    if (hypot(this.px - e.x, this.py - e.y) < r + this.pr) this.hurtPlayer(e.dmg * 1.6);
    for (const o of this.enemies) {
      if (!o.alive || o === e) continue;
      if (hypot(o.x - e.x, o.y - e.y) < r + o.r) this.hurtEnemy(o, 28, false);
    }
  }

  private updateBullets(dt: number) {
    for (const b of this.bullets) {
      if (!b.alive) continue;
      if (b.homing > 0 && b.team === 0) {
        const t = this.nearest(b.x, b.y, 240);
        if (t) {
          const a = atan2(t.y - b.y, t.x - b.x);
          const spd = hypot(b.vx, b.vy);
          const ca = atan2(b.vy, b.vx);
          let d = a - ca;
          while (d > Math.PI) d -= TAU;
          while (d < -Math.PI) d += TAU;
          const na = ca + clamp(d, -b.homing * dt, b.homing * dt);
          b.vx = cos(na) * spd;
          b.vy = sin(na) * spd;
        }
      }
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      b.life -= dt;
      if (b.life <= 0) b.alive = false;
      else if (hypot(b.x - this.camX, b.y - this.camY) > Math.max(this.w, this.h) * 0.9) b.alive = false;
    }
  }

  private updateGems(dt: number) {
    const mag = 78 + this.lvOf("magnet") * 46;
    for (const g of this.gems) {
      if (!g.alive) continue;
      g.t += dt;
      const dx = this.px - g.x;
      const dy = this.py - g.y;
      const d = hypot(dx, dy);
      if (d < mag) {
        const pull = 420 + this.lvOf("magnet") * 90;
        g.vx += (dx / (d || 1)) * pull * dt;
        g.vy += (dy / (d || 1)) * pull * dt;
      }
      g.vx *= Math.pow(0.08, dt);
      g.vy *= Math.pow(0.08, dt);
      g.x += g.vx * dt;
      g.y += g.vy * dt;
      if (d < 18) {
        g.alive = false;
        this.grantXp(g.v);
        this.audio.pickup();
      }
    }
  }

  private updateFx(dt: number) {
    for (const p of this.parts) {
      if (!p.alive) continue;
      p.life -= dt;
      if (p.life <= 0) {
        p.alive = false;
        continue;
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vx *= p.drag;
      p.vy *= p.drag;
      p.size += p.growth * dt;
      p.rot += p.rv * dt;
    }
    for (const f of this.floats) {
      if (!f.alive) continue;
      f.life -= dt;
      f.y += f.vy * dt;
      f.vy *= 0.96;
      if (f.life <= 0) f.alive = false;
    }
    for (const b of this.bolts) b.life -= dt * 4.5;
    this.bolts = this.bolts.filter((b) => b.life > 0);
  }

  private collide() {
    const orbit = this.lvOf("orbit");
    if (orbit > 0) {
      const n = 2 + orbit;
      const rad = (46 + orbit * 10) * this.areaMul();
      const dmg = 7 * this.dmgMul() * (1 + orbit * 0.2);
      const ang0 = this.time * (2.4 + orbit * 0.35);
      for (let i = 0; i < n; i++) {
        const a = ang0 + (i * TAU) / n;
        const ox = this.px + cos(a) * rad;
        const oy = this.py + sin(a) * rad;
        for (const e of this.enemies) {
          if (!e.alive || e.contactCd > 0) continue;
          if (hypot(e.x - ox, e.y - oy) < e.r + 10 * this.areaMul()) {
            this.hurtEnemy(e, dmg, false);
            e.contactCd = 0.18;
          }
        }
      }
    }

    for (const b of this.bullets) {
      if (!b.alive) continue;
      if (b.team === 0) {
        for (const e of this.enemies) {
          if (!e.alive) continue;
          let hit = hypot(e.x - b.x, e.y - b.y) < e.r + b.r;
          if (!hit && e.segs) {
            for (const s of e.segs) {
              if (hypot(s.x - b.x, s.y - b.y) < 12 + b.r) {
                hit = true;
                break;
              }
            }
          }
          if (!hit) continue;
          let dmg = b.dmg;
          const crit = Math.random() < 0.08 + this.lvOf("crit") * 0.08;
          if (crit) dmg *= 2.4;
          this.hurtEnemy(e, dmg, crit, b.x, b.y);
          if (this.lvOf("storm") > 0) this.chain(e, dmg * 0.7, this.lvOf("storm") + 1);
          if (b.pierce > 0) b.pierce -= 1;
          else {
            b.alive = false;
            break;
          }
        }
      } else if (!this.dead) {
        if (hypot(b.x - this.px, b.y - this.py) < this.pr + b.r) {
          b.alive = false;
          this.hurtPlayer(b.dmg);
        }
      }
    }

    if (this.dead || this.invuln > 0) return;
    for (const e of this.enemies) {
      if (!e.alive) continue;
      let d = hypot(e.x - this.px, e.y - this.py);
      let r = e.r + this.pr - 3;
      if (e.segs) {
        for (const s of e.segs) {
          const sd = hypot(s.x - this.px, s.y - this.py);
          if (sd < 12 + this.pr) {
            d = sd;
            r = 12 + this.pr;
            break;
          }
        }
      }
      if (d < r) this.hurtPlayer(e.dmg);
    }
  }

  private chain(from: Enemy, dmg: number, jumps: number) {
    const ignore = new Set<Enemy>([from]);
    let cx = from.x;
    let cy = from.y;
    for (let i = 0; i < jumps; i++) {
      let best: Enemy | null = null;
      let bestD = 150;
      for (const e of this.enemies) {
        if (!e.alive || ignore.has(e)) continue;
        const d = hypot(e.x - cx, e.y - cy);
        if (d < bestD) {
          bestD = d;
          best = e;
        }
      }
      if (!best) break;
      this.bolts.push({ x1: cx, y1: cy, x2: best.x, y2: best.y, life: 1 });
      this.hurtEnemy(best, dmg, false);
      ignore.add(best);
      cx = best.x;
      cy = best.y;
      dmg *= 0.72;
    }
  }

  private hurtEnemy(e: Enemy, dmg: number, crit: boolean, hx?: number, hy?: number) {
    if (!e.alive) return;
    e.hp -= dmg;
    e.flash = 1;
    const kb = 40 / Math.max(8, e.r);
    const a = atan2(e.y - this.py, e.x - this.px);
    e.vx += cos(a) * kb * 12;
    e.vy += sin(a) * kb * 12;
    const x = hx ?? e.x;
    const y = hy ?? e.y;
    this.spark(x, y, e.kind === "elite" ? 255 : 180, 240, 255, crit ? 10 : 4);
    this.floatText(e.x, e.y - e.r, String(Math.round(dmg)), crit ? 255 : 230, crit ? 209 : 250, crit ? 102 : 255, crit ? 18 : 14);
    if (this.lvOf("storm") && Math.random() < 0.12) e.freeze = Math.max(e.freeze, 0.45);
    if (e.hp <= 0) this.kill(e);
  }

  private kill(e: Enemy) {
    e.alive = false;
    this.kills += 1;
    this.combo += 1;
    this.comboT = 1.65;
    this.comboMax = Math.max(this.comboMax, this.combo);
    const mul = 1 + Math.min(12, this.combo) * 0.12;
    this.score += Math.round(e.worth * mul * (1 + this.wave * 0.04));
    const luck = 1 + this.lvOf("luck") * 0.15;
    this.dropGem(e.x, e.y, Math.round(e.xp * luck));
    if (Math.random() < 0.04 + this.lvOf("luck") * 0.02) this.dropGem(e.x + 8, e.y, Math.round(e.xp * 0.8));
    const [cr, cg, cb] = this.enemyColor(e.kind);
    const n = e.r > 40 ? 48 : e.r > 18 ? 22 : 12;
    this.burst(e.x, e.y, cr, cg, cb, n, 140 + e.r * 4);
    this.ring(e.x, e.y, cr, cg, cb, e.r * 1.4);
    this.shake = Math.min(26, this.shake + (e.r > 40 ? 14 : 3));
    this.hitstop = e.r > 40 ? 0.08 : 0.018;
    this.audio.explode(e.r > 40 ? 1.6 : 0.6);
    if (this.combo > 1 && this.combo % 5 === 0) {
      this.audio.combo(this.combo);
      this.floatText(this.px, this.py - 36, "x" + this.combo + " COMBO", 110, 246, 255, 16);
    }
    if (e.kind === "splitter" && e.gen < 1) {
      for (let i = 0; i < 2; i++) this.spawnEnemy("splitter", e.x + rand(-8, 8), e.y + rand(-8, 8), 1);
    }
    if (e.r > 40) {
      this.timeScale = 0.28;
      this.banner = { text: "GUARDIAN DOWN", sub: "+" + e.worth + " pts", t: 1.8, col: "#ffd166" };
      this.flash = 0.55;
    }
  }

  private hurtPlayer(dmg: number) {
    if (this.invuln > 0 || this.dead) return;
    let rest = dmg;
    if (this.shield > 0) {
      const use = Math.min(this.shield, rest);
      this.shield -= use;
      rest -= use;
    }
    if (rest > 0) this.hp -= rest;
    this.invuln = 0.7;
    this.shake = Math.min(28, this.shake + 12);
    this.flash = 0.65;
    this.audio.hurt();
    this.burst(this.px, this.py, 255, 60, 90, 20, 200);
    if (this.hp <= 0) {
      this.hp = 0;
      this.dead = true;
      this.deadT = 0;
      this.timeScale = 0.22;
      this.burst(this.px, this.py, 110, 246, 255, 70, 420);
      this.ring(this.px, this.py, 255, 60, 172, 80);
      this.audio.explode(2);
    }
  }

  private grantXp(v: number) {
    this.xp += v;
    if (this.xp >= this.xpNeed) this.levelUp();
  }

  private levelUp() {
    if (this.awaitingUpgrade || this.dead) return;
    this.xp -= this.xpNeed;
    this.lv += 1;
    this.xpNeed = Math.round(40 * Math.pow(1.22, this.lv - 1));
    this.hp = Math.min(this.maxHp, this.hp + 12);
    this.audio.levelUp();
    this.banner = { text: "SYSTEM UP", sub: "choose a protocol", t: 1.2, col: "#ffd166" };
    this.flash = 0.3;
    const choices = this.rollUpgrades();
    if (!choices.length) return;
    this.choices = choices;
    this.awaitingUpgrade = true;
    this.hooks.onUpgrade(choices);
  }

  private rollUpgrades() {
    const pool = UPGRADES.filter((u) => this.lvOf(u.id) < u.max);
    const out: UpgradeDef[] = [];
    const copy = [...pool];
    while (out.length < 3 && copy.length) {
      const total = copy.reduce((s, u) => s + u.weight, 0);
      let r = Math.random() * total;
      let idx = 0;
      for (let i = 0; i < copy.length; i++) {
        r -= copy[i].weight;
        if (r <= 0) {
          idx = i;
          break;
        }
      }
      out.push(copy.splice(idx, 1)[0]);
    }
    return out;
  }

  private finish() {
    if (this.ended) return;
    this.ended = true;
    const stats: GameStats = {
      score: this.score,
      wave: this.wave,
      kills: this.kills,
      time: this.time,
      level: this.lv,
      comboMax: this.comboMax,
      best: getBestScore(),
    };
    if (this.score > stats.best) {
      stats.best = this.score;
      try {
        localStorage.setItem(BEST_KEY, String(this.score));
      } catch {
        /* ignore */
      }
    }
    this.hooks.onGameOver(stats);
  }

  private spawnBullet(
    x: number,
    y: number,
    ang: number,
    spd: number,
    dmg: number,
    pierce: number,
    r: number,
    team: 0 | 1,
    cr: number,
    cg: number,
    cb: number,
    homing = 0,
  ) {
    let b = this.bullets.find((o) => !o.alive);
    if (!b) {
      if (this.bullets.length > 420) return;
      b = {
        alive: true,
        x: 0,
        y: 0,
        vx: 0,
        vy: 0,
        r: 4,
        dmg: 1,
        life: 1,
        team: 0,
        pierce: 0,
        homing: 0,
        cr: 255,
        cg: 255,
        cb: 255,
      };
      this.bullets.push(b);
    }
    b.alive = true;
    b.x = x;
    b.y = y;
    b.vx = cos(ang) * spd;
    b.vy = sin(ang) * spd;
    b.r = r;
    b.dmg = dmg;
    b.life = team === 0 ? 1.15 : 2.4;
    b.team = team;
    b.pierce = pierce;
    b.homing = homing;
    b.cr = cr;
    b.cg = cg;
    b.cb = cb;
  }

  private dropGem(x: number, y: number, v: number) {
    let g = this.gems.find((o) => !o.alive);
    if (!g) {
      if (this.gems.length > 260) return;
      g = { alive: true, x: 0, y: 0, vx: 0, vy: 0, v: 1, r: 5, t: 0 };
      this.gems.push(g);
    }
    g.alive = true;
    g.x = x;
    g.y = y;
    g.vx = rand(-80, 80);
    g.vy = rand(-80, 80);
    g.v = v;
    g.r = v > 16 ? 7 : 5;
    g.t = 0;
  }

  private allocP(): Particle | null {
    let p = this.parts.find((o) => !o.alive);
    if (!p) {
      if (this.parts.length > 1700) return this.parts[(Math.random() * this.parts.length) | 0];
      p = {
        alive: false,
        x: 0,
        y: 0,
        vx: 0,
        vy: 0,
        life: 0,
        max: 1,
        size: 2,
        growth: 0,
        cr: 255,
        cg: 255,
        cb: 255,
        kind: 0,
        rot: 0,
        rv: 0,
        drag: 0.96,
      };
      this.parts.push(p);
    }
    return p;
  }

  private burst(x: number, y: number, cr: number, cg: number, cb: number, n: number, spd: number) {
    for (let i = 0; i < n; i++) {
      const p = this.allocP();
      if (!p) return;
      const a = rand(0, TAU);
      const s = rand(0.15, 1) * spd;
      p.alive = true;
      p.x = x;
      p.y = y;
      p.vx = cos(a) * s;
      p.vy = sin(a) * s;
      p.max = rand(0.25, 0.7);
      p.life = p.max;
      p.size = rand(1.4, 4.2);
      p.growth = -p.size / p.max;
      p.cr = cr;
      p.cg = cg;
      p.cb = cb;
      p.kind = Math.random() < 0.35 ? 1 : 0;
      p.rot = a;
      p.rv = rand(-8, 8);
      p.drag = 0.94;
    }
  }

  private ring(x: number, y: number, cr: number, cg: number, cb: number, size: number) {
    const p = this.allocP();
    if (!p) return;
    p.alive = true;
    p.x = x;
    p.y = y;
    p.vx = 0;
    p.vy = 0;
    p.max = 0.45;
    p.life = p.max;
    p.size = size * 0.25;
    p.growth = size * 2.2;
    p.cr = cr;
    p.cg = cg;
    p.cb = cb;
    p.kind = 2;
    p.rot = 0;
    p.rv = 0;
    p.drag = 1;
  }

  private spark(x: number, y: number, cr: number, cg: number, cb: number, n: number) {
    for (let i = 0; i < n; i++) {
      const p = this.allocP();
      if (!p) return;
      const a = rand(0, TAU);
      p.alive = true;
      p.x = x;
      p.y = y;
      p.vx = cos(a) * rand(40, 220);
      p.vy = sin(a) * rand(40, 220);
      p.max = rand(0.12, 0.28);
      p.life = p.max;
      p.size = rand(2, 6);
      p.growth = -10;
      p.cr = cr;
      p.cg = cg;
      p.cb = cb;
      p.kind = 1;
      p.rot = a;
      p.rv = 0;
      p.drag = 0.9;
    }
  }

  private floatText(x: number, y: number, text: string, cr: number, cg: number, cb: number, size: number) {
    let f = this.floats.find((o) => !o.alive);
    if (!f) {
      if (this.floats.length > 80) return;
      f = { alive: false, x: 0, y: 0, vy: 0, text: "", life: 0, max: 1, cr: 255, cg: 255, cb: 255, size: 14 };
      this.floats.push(f);
    }
    f.alive = true;
    f.x = x;
    f.y = y;
    f.vy = -42;
    f.text = text;
    f.max = 0.7;
    f.life = f.max;
    f.cr = cr;
    f.cg = cg;
    f.cb = cb;
    f.size = size;
  }

  private nearest(x: number, y: number, maxD: number) {
    let best: Enemy | null = null;
    let bd = maxD;
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const d = hypot(e.x - x, e.y - y);
      if (d < bd) {
        bd = d;
        best = e;
      }
    }
    return best;
  }

  private enemyColor(kind: EnemyKind): [number, number, number] {
    switch (kind) {
      case "wisp":
        return [92, 225, 255];
      case "dart":
        return [255, 61, 138];
      case "tank":
        return [255, 138, 61];
      case "splitter":
        return [124, 255, 107];
      case "orbiter":
        return [196, 92, 255];
      case "sniper":
        return [255, 77, 77];
      case "swarm":
        return [255, 229, 102];
      case "bomber":
        return [255, 107, 157];
      case "elite":
        return [255, 209, 102];
      case "hexboss":
        return [110, 246, 255];
      case "serpent":
        return [255, 60, 172];
      case "coreboss":
        return [255, 209, 102];
    }
  }

  private sx(x: number) {
    return x - this.camX + this.w / 2;
  }
  private sy(y: number) {
    return y - this.camY + this.h / 2;
  }

  private draw(now: number) {
    const ctx = this.ctx;
    const { w, h, dpr } = this;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const shx = (Math.random() - 0.5) * this.shake;
    const shy = (Math.random() - 0.5) * this.shake;

    ctx.globalCompositeOperation = "source-over";
    if (this.paused || this.awaitingUpgrade || this.ended) {
      ctx.fillStyle = "#05010d";
      ctx.fillRect(0, 0, w, h);
    } else {
      ctx.fillStyle = "rgba(5,1,13,0.42)";
      ctx.fillRect(0, 0, w, h);
    }

    ctx.save();
    ctx.translate(shx, shy);

    if (this.nebula.complete && this.nebula.naturalWidth) {
      ctx.globalAlpha = 0.28;
      const nw = w * 1.45;
      const nh = h * 1.45;
      ctx.drawImage(this.nebula, -w * 0.18 - this.camX * 0.03, -h * 0.18 - this.camY * 0.03, nw, nh);
      ctx.globalAlpha = 1;
    }

    this.drawStars(ctx, now);
    this.drawGrid(ctx);

    ctx.globalCompositeOperation = "lighter";
    this.drawGems(ctx);
    this.drawParticles(ctx, 0);
    ctx.globalCompositeOperation = "source-over";
    this.drawEnemies(ctx);
    this.drawGhosts(ctx);
    this.drawPlayer(ctx);
    ctx.globalCompositeOperation = "lighter";
    this.drawBullets(ctx);
    this.drawBolts(ctx);
    this.drawOrbit(ctx);
    this.drawParticles(ctx, 1);
    ctx.globalCompositeOperation = "source-over";
    this.drawFloats(ctx);

    ctx.restore();
    this.drawHud(ctx);
    if (this.flash > 0) {
      ctx.fillStyle = `rgba(255,70,110,${this.flash * 0.28})`;
      ctx.fillRect(0, 0, w, h);
    }
    const vg = 0.35 + this.vignette * 0.4;
    const g = ctx.createRadialGradient(w / 2, h / 2, h * 0.25, w / 2, h / 2, h * 0.78);
    g.addColorStop(0, "rgba(0,0,0,0)");
    g.addColorStop(1, `rgba(0,0,0,${vg})`);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  }

  private drawStars(ctx: CanvasRenderingContext2D, now: number) {
    for (const s of this.stars) {
      const x = ((s.x * this.w - this.camX * s.z * 0.04) % this.w + this.w) % this.w;
      const y = ((s.y * this.h - this.camY * s.z * 0.04) % this.h + this.h) % this.h;
      const tw = 0.45 + 0.55 * (0.5 + 0.5 * sin(now * 0.002 + s.tw));
      ctx.fillStyle = `rgba(210,240,255,${0.25 + s.z * 0.55 * tw})`;
      ctx.beginPath();
      ctx.arc(x, y, s.r * s.z, 0, TAU);
      ctx.fill();
    }
  }

  private drawGrid(ctx: CanvasRenderingContext2D) {
    const step = 88;
    const ox = -((this.camX % step) + step) % step;
    const oy = -((this.camY % step) + step) % step;
    ctx.strokeStyle = "rgba(110,246,255,0.045)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = ox; x < this.w + step; x += step) {
      ctx.moveTo(x, 0);
      ctx.lineTo(x, this.h);
    }
    for (let y = oy; y < this.h + step; y += step) {
      ctx.moveTo(0, y);
      ctx.lineTo(this.w, y);
    }
    ctx.stroke();
    ctx.strokeStyle = "rgba(255,60,172,0.03)";
    ctx.beginPath();
    for (let x = ox + step / 2; x < this.w + step; x += step * 2) {
      ctx.moveTo(x, 0);
      ctx.lineTo(x, this.h);
    }
    ctx.stroke();
  }

  private drawGems(ctx: CanvasRenderingContext2D) {
    for (const g of this.gems) {
      if (!g.alive) continue;
      const x = this.sx(g.x);
      const y = this.sy(g.y);
      if (x < -20 || y < -20 || x > this.w + 20 || y > this.h + 20) continue;
      const pulse = 0.7 + 0.3 * sin(g.t * 8);
      ctx.fillStyle = `rgba(255,209,102,${0.18 * pulse})`;
      ctx.beginPath();
      ctx.arc(x, y, g.r * 3.2, 0, TAU);
      ctx.fill();
      ctx.fillStyle = `rgba(255,240,170,${0.9})`;
      ctx.beginPath();
      ctx.moveTo(x, y - g.r);
      ctx.lineTo(x + g.r * 0.75, y);
      ctx.lineTo(x, y + g.r);
      ctx.lineTo(x - g.r * 0.75, y);
      ctx.closePath();
      ctx.fill();
    }
  }

  private drawEnemies(ctx: CanvasRenderingContext2D) {
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const x = this.sx(e.x);
      const y = this.sy(e.y);
      if (x < -80 || y < -80 || x > this.w + 80 || y > this.h + 80) {
        if (e.kind !== "serpent") continue;
      }
      const [cr, cg, cb] = this.enemyColor(e.kind);
      const f = e.flash;
      const col = f > 0 ? `rgb(${lerp(cr, 255, f) | 0},${lerp(cg, 255, f) | 0},${lerp(cb, 255, f) | 0})` : `rgb(${cr},${cg},${cb})`;
      if (e.kind === "hexboss" && e.state === 1) {
        ctx.strokeStyle = "rgba(255,70,90,0.55)";
        ctx.lineWidth = 2;
        ctx.setLineDash([8, 8]);
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(this.sx(e.teleX), this.sy(e.teleY));
        ctx.stroke();
        ctx.setLineDash([]);
      }
      if (e.kind === "serpent" && e.segs) {
        for (let i = e.segs.length - 1; i >= 0; i--) {
          const s = e.segs[i];
          const sx = this.sx(s.x);
          const sy = this.sy(s.y);
          const rr = 11 - i * 0.25;
          ctx.fillStyle = `rgba(${cr},${cg},${cb},${0.16})`;
          ctx.beginPath();
          ctx.arc(sx, sy, rr * 2.1, 0, TAU);
          ctx.fill();
          ctx.fillStyle = col;
          ctx.beginPath();
          ctx.arc(sx, sy, rr, 0, TAU);
          ctx.fill();
        }
      }
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(e.angle);
      ctx.fillStyle = `rgba(${cr},${cg},${cb},0.18)`;
      ctx.beginPath();
      ctx.arc(0, 0, e.r * 1.85, 0, TAU);
      ctx.fill();
      ctx.fillStyle = col;
      ctx.strokeStyle = `rgba(255,255,255,0.55)`;
      ctx.lineWidth = 1.2;
      this.drawKind(ctx, e);
      ctx.restore();
      if (e.maxHp > 40 || e.kind.includes("boss")) {
        const bw = Math.max(28, e.r * 1.6);
        ctx.fillStyle = "rgba(0,0,0,0.45)";
        ctx.fillRect(x - bw / 2, y - e.r - 12, bw, 4);
        ctx.fillStyle = `rgb(${cr},${cg},${cb})`;
        ctx.fillRect(x - bw / 2, y - e.r - 12, bw * clamp(e.hp / e.maxHp, 0, 1), 4);
      }
    }
  }

  private drawKind(ctx: CanvasRenderingContext2D, e: Enemy) {
    const r = e.r;
    switch (e.kind) {
      case "wisp":
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, TAU);
        ctx.fill();
        ctx.fillStyle = "rgba(255,255,255,0.7)";
        ctx.beginPath();
        ctx.arc(-r * 0.2, -r * 0.2, r * 0.35, 0, TAU);
        ctx.fill();
        break;
      case "swarm":
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, TAU);
        ctx.fill();
        break;
      case "dart":
        ctx.beginPath();
        ctx.moveTo(r * 1.3, 0);
        ctx.lineTo(-r * 0.9, r * 0.7);
        ctx.lineTo(-r * 0.4, 0);
        ctx.lineTo(-r * 0.9, -r * 0.7);
        ctx.closePath();
        ctx.fill();
        break;
      case "tank":
        poly(ctx, 5, r, 0);
        ctx.fill();
        ctx.stroke();
        break;
      case "splitter":
        poly(ctx, 4, r, Math.PI / 4);
        ctx.fill();
        ctx.stroke();
        break;
      case "orbiter":
        poly(ctx, 6, r, 0);
        ctx.fill();
        break;
      case "sniper":
        ctx.beginPath();
        ctx.moveTo(r * 1.4, 0);
        ctx.lineTo(-r, r * 0.45);
        ctx.lineTo(-r, -r * 0.45);
        ctx.closePath();
        ctx.fill();
        break;
      case "bomber":
        poly(ctx, 8, r, 0);
        ctx.fill();
        ctx.strokeStyle = e.state > 0.2 ? "rgba(255,80,80,0.9)" : "rgba(255,255,255,0.4)";
        ctx.stroke();
        break;
      case "elite":
        poly(ctx, 6, r, this.time * 1.2);
        ctx.fill();
        poly(ctx, 3, r * 0.45, -this.time);
        ctx.stroke();
        break;
      case "hexboss":
        poly(ctx, 6, r, e.spin);
        ctx.fill();
        ctx.stroke();
        poly(ctx, 6, r * 0.55, -e.spin);
        ctx.stroke();
        break;
      case "serpent":
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, TAU);
        ctx.fill();
        ctx.fillStyle = "#05010d";
        ctx.beginPath();
        ctx.arc(r * 0.35, -r * 0.25, 3.2, 0, TAU);
        ctx.arc(r * 0.35, r * 0.25, 3.2, 0, TAU);
        ctx.fill();
        break;
      case "coreboss":
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, TAU);
        ctx.fill();
        ctx.strokeStyle = "rgba(255,255,255,0.7)";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, 0, r * 0.62, 0, TAU);
        ctx.stroke();
        poly(ctx, 4, r * 0.35, e.spin);
        ctx.stroke();
        break;
    }
  }

  private drawGhosts(ctx: CanvasRenderingContext2D) {
    for (const g of this.ghosts) {
      const x = this.sx(g.x);
      const y = this.sy(g.y);
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(g.a);
      ctx.globalAlpha = g.life * 2.2;
      ctx.fillStyle = "rgba(110,246,255,0.35)";
      ctx.beginPath();
      ctx.moveTo(14, 0);
      ctx.lineTo(-10, 8);
      ctx.lineTo(-6, 0);
      ctx.lineTo(-10, -8);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
    ctx.globalAlpha = 1;
  }

  private drawPlayer(ctx: CanvasRenderingContext2D) {
    if (this.dead && this.deadT > 0.4) return;
    if (this.trail.length > 2) {
      ctx.strokeStyle = "rgba(110,246,255,0.35)";
      ctx.lineWidth = 6;
      ctx.lineCap = "round";
      ctx.beginPath();
      for (let i = 0; i < this.trail.length; i++) {
        const t = this.trail[i];
        const x = this.sx(t.x);
        const y = this.sy(t.y);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
    const x = this.sx(this.px);
    const y = this.sy(this.py);
    const blink = this.invuln > 0 && Math.sin(this.invuln * 40) > 0 ? 0.4 : 1;
    ctx.save();
    ctx.translate(x, y);
    ctx.globalAlpha = blink;
    if (this.maxShield > 0 && this.shield > 0) {
      ctx.strokeStyle = `rgba(139,92,255,${0.35 + 0.35 * (this.shield / this.maxShield)})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 0, 22, 0, TAU);
      ctx.stroke();
    }
    ctx.rotate(this.pang);
    ctx.fillStyle = "rgba(110,246,255,0.25)";
    ctx.beginPath();
    ctx.arc(-6, 0, 16, 0, TAU);
    ctx.fill();
    ctx.fillStyle = "#e9ffff";
    ctx.beginPath();
    ctx.moveTo(16, 0);
    ctx.lineTo(-12, 10);
    ctx.lineTo(-7, 0);
    ctx.lineTo(-12, -10);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#6ef6ff";
    ctx.beginPath();
    ctx.moveTo(6, 0);
    ctx.lineTo(-8, 5);
    ctx.lineTo(-5, 0);
    ctx.lineTo(-8, -5);
    ctx.closePath();
    ctx.fill();
    const thrust = 8 + hypot(this.pvx, this.pvy) * 0.02 + (this.dashT > 0 ? 10 : 0);
    ctx.fillStyle = "rgba(255,60,172,0.85)";
    ctx.beginPath();
    ctx.moveTo(-12, 4);
    ctx.lineTo(-12 - thrust, 0);
    ctx.lineTo(-12, -4);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
    ctx.globalAlpha = 1;

    if (this.lvOf("drone") > 0) {
      const dx = this.sx(this.drone.x);
      const dy = this.sy(this.drone.y);
      ctx.fillStyle = "rgba(180,255,200,0.25)";
      ctx.beginPath();
      ctx.arc(dx, dy, 12, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "#b4ffc8";
      ctx.beginPath();
      ctx.arc(dx, dy, 5, 0, TAU);
      ctx.fill();
    }

    if (this.dashCd > 0) {
      ctx.strokeStyle = "rgba(110,246,255,0.35)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(x, y + 26, 7, -Math.PI / 2, -Math.PI / 2 + TAU * (1 - this.dashCd / (this.dashMax * (1 - this.lvOf("dash") * 0.18))));
      ctx.stroke();
    }
  }

  private drawOrbit(ctx: CanvasRenderingContext2D) {
    const orbit = this.lvOf("orbit");
    if (!orbit || this.dead) return;
    const n = 2 + orbit;
    const rad = (46 + orbit * 10) * this.areaMul();
    const ang0 = this.time * (2.4 + orbit * 0.35);
    for (let i = 0; i < n; i++) {
      const a = ang0 + (i * TAU) / n;
      const x = this.sx(this.px + cos(a) * rad);
      const y = this.sy(this.py + sin(a) * rad);
      ctx.fillStyle = "rgba(255,60,172,0.25)";
      ctx.beginPath();
      ctx.arc(x, y, 12, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "#ffd166";
      ctx.beginPath();
      ctx.arc(x, y, 5, 0, TAU);
      ctx.fill();
    }
  }

  private drawBullets(ctx: CanvasRenderingContext2D) {
    for (const b of this.bullets) {
      if (!b.alive) continue;
      const x = this.sx(b.x);
      const y = this.sy(b.y);
      if (x < -30 || y < -30 || x > this.w + 30 || y > this.h + 30) continue;
      ctx.fillStyle = `rgba(${b.cr},${b.cg},${b.cb},0.22)`;
      ctx.beginPath();
      ctx.arc(x, y, b.r * 3.2, 0, TAU);
      ctx.fill();
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(atan2(b.vy, b.vx));
      ctx.fillStyle = `rgb(${b.cr},${b.cg},${b.cb})`;
      ctx.beginPath();
      ctx.roundRect(-b.r * 1.8, -b.r * 0.55, b.r * 3.6, b.r * 1.1, 4);
      ctx.fill();
      ctx.fillStyle = "#fff";
      ctx.beginPath();
      ctx.arc(b.r * 0.4, 0, b.r * 0.35, 0, TAU);
      ctx.fill();
      ctx.restore();
    }
  }

  private drawBolts(ctx: CanvasRenderingContext2D) {
    for (const b of this.bolts) {
      ctx.strokeStyle = `rgba(180,255,255,${b.life})`;
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.moveTo(this.sx(b.x1), this.sy(b.y1));
      const mx = (b.x1 + b.x2) / 2 + rand(-10, 10);
      const my = (b.y1 + b.y2) / 2 + rand(-10, 10);
      ctx.lineTo(this.sx(mx), this.sy(my));
      ctx.lineTo(this.sx(b.x2), this.sy(b.y2));
      ctx.stroke();
    }
  }

  private drawParticles(ctx: CanvasRenderingContext2D, pass: 0 | 1) {
    for (const p of this.parts) {
      if (!p.alive) continue;
      if (pass === 0 && p.kind === 2) continue;
      if (pass === 1 && p.kind !== 2 && p.kind !== 0) continue;
      const x = this.sx(p.x);
      const y = this.sy(p.y);
      if (x < -40 || y < -40 || x > this.w + 40 || y > this.h + 40) continue;
      const a = clamp(p.life / p.max, 0, 1);
      if (p.kind === 2) {
        ctx.strokeStyle = `rgba(${p.cr},${p.cg},${p.cb},${a * 0.7})`;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(x, y, Math.max(1, p.size), 0, TAU);
        ctx.stroke();
      } else if (p.kind === 1) {
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(p.rot);
        ctx.strokeStyle = `rgba(${p.cr},${p.cg},${p.cb},${a})`;
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.moveTo(-p.size, 0);
        ctx.lineTo(p.size * 1.6, 0);
        ctx.stroke();
        ctx.restore();
      } else {
        ctx.fillStyle = `rgba(${p.cr},${p.cg},${p.cb},${a})`;
        ctx.beginPath();
        ctx.arc(x, y, Math.max(0.4, p.size), 0, TAU);
        ctx.fill();
      }
    }
  }

  private drawFloats(ctx: CanvasRenderingContext2D) {
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    for (const f of this.floats) {
      if (!f.alive) continue;
      const a = clamp(f.life / f.max, 0, 1);
      ctx.font = `700 ${f.size}px Rajdhani, sans-serif`;
      ctx.fillStyle = `rgba(${f.cr},${f.cg},${f.cb},${a})`;
      ctx.fillText(f.text, this.sx(f.x), this.sy(f.y));
    }
  }

  private drawHud(ctx: CanvasRenderingContext2D) {
    const { w, h } = this;
    ctx.save();
    ctx.textBaseline = "top";

    ctx.fillStyle = "rgba(0,0,0,0.35)";
    ctx.beginPath();
    ctx.roundRect(18, 16, 240, 54, 10);
    ctx.fill();
    ctx.fillStyle = "rgba(255,60,90,0.15)";
    ctx.fillRect(28, 28, 220, 10);
    ctx.fillStyle = "#ff5d7a";
    ctx.fillRect(28, 28, 220 * clamp(this.hp / this.maxHp, 0, 1), 10);
    if (this.maxShield > 0) {
      ctx.fillStyle = "rgba(139,92,255,0.25)";
      ctx.fillRect(28, 42, 220, 7);
      ctx.fillStyle = "#8b5cff";
      ctx.fillRect(28, 42, 220 * clamp(this.shield / this.maxShield, 0, 1), 7);
    }
    ctx.font = "600 13px Rajdhani, sans-serif";
    ctx.fillStyle = "rgba(231,247,255,0.7)";
    ctx.textAlign = "left";
    ctx.fillText(`HULL ${Math.ceil(this.hp)}/${this.maxHp}`, 28, 52);

    ctx.textAlign = "right";
    ctx.font = "800 28px Orbitron, sans-serif";
    ctx.fillStyle = "#e7f7ff";
    ctx.fillText(String(this.score).padStart(6, "0"), w - 22, 16);
    ctx.font = "600 14px Rajdhani, sans-serif";
    ctx.fillStyle = "rgba(110,246,255,0.75)";
    ctx.fillText(`WAVE ${this.wave}   LV ${this.lv}`, w - 22, 48);

    if (this.combo > 1) {
      ctx.textAlign = "center";
      ctx.font = "800 22px Orbitron, sans-serif";
      ctx.fillStyle = "#6ef6ff";
      ctx.fillText(`x${this.combo} COMBO`, w / 2, 18);
      ctx.fillStyle = "rgba(110,246,255,0.25)";
      ctx.fillRect(w / 2 - 50, 44, 100, 4);
      ctx.fillStyle = "#6ef6ff";
      ctx.fillRect(w / 2 - 50, 44, 100 * clamp(this.comboT / 1.65, 0, 1), 4);
    }

    ctx.fillStyle = "rgba(0,0,0,0.4)";
    ctx.fillRect(w * 0.22, h - 28, w * 0.56, 8);
    ctx.fillStyle = "#ffd166";
    ctx.fillRect(w * 0.22, h - 28, w * 0.56 * clamp(this.xp / this.xpNeed, 0, 1), 8);
    ctx.strokeStyle = "rgba(255,209,102,0.35)";
    ctx.strokeRect(w * 0.22, h - 28, w * 0.56, 8);

    if (this.banner.t > 0) {
      const a = Math.min(1, this.banner.t * 1.4, this.banner.t);
      ctx.textAlign = "center";
      ctx.font = "800 42px Orbitron, sans-serif";
      ctx.fillStyle = hexToRgba(this.banner.col, a);
      ctx.fillText(this.banner.text, w / 2, h * 0.22);
      ctx.font = "600 16px Rajdhani, sans-serif";
      ctx.fillStyle = `rgba(231,247,255,${a * 0.8})`;
      ctx.fillText(this.banner.sub, w / 2, h * 0.22 + 48);
    }

    ctx.restore();
  }
}

function hexToRgba(h: string, a: number) {
  const [r, g, b] = hexRgb(h);
  return `rgba(${r},${g},${b},${a})`;
}
