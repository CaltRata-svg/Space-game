export class AudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private sfx: GainNode | null = null;
  private music: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private drone: OscillatorNode | null = null;
  private drone2: OscillatorNode | null = null;
  private lfo: OscillatorNode | null = null;
  private musicHandle = 0;
  private step = 0;
  private lastShot = 0;
  muted = false;
  intensity = 0;

  async ensure() {
    if (!this.ctx) {
      const ctx = new AudioContext();
      this.ctx = ctx;
      this.master = ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.32;
      this.master.connect(ctx.destination);

      this.sfx = ctx.createGain();
      this.sfx.gain.value = 0.85;
      this.sfx.connect(this.master);

      this.music = ctx.createGain();
      this.music.gain.value = 0.5;
      this.music.connect(this.master);

      this.noise = ctx.createBuffer(1, ctx.sampleRate * 1.5, ctx.sampleRate);
      const data = this.noise.getChannelData(0);
      for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    }
    if (this.ctx.state === "suspended") await this.ctx.resume();
  }

  setMuted(muted: boolean) {
    this.muted = muted;
    if (this.master) this.master.gain.value = muted ? 0 : 0.32;
  }

  startMusic() {
    if (!this.ctx || !this.music || this.drone) return;
    const ctx = this.ctx;

    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 420;
    filter.Q.value = 0.7;
    filter.connect(this.music);

    const dg = ctx.createGain();
    dg.gain.value = 0.07;
    dg.connect(filter);

    const o1 = ctx.createOscillator();
    o1.type = "sine";
    o1.frequency.value = 55;
    o1.connect(dg);
    o1.start();
    this.drone = o1;

    const o2 = ctx.createOscillator();
    o2.type = "triangle";
    o2.frequency.value = 82.4;
    const g2 = ctx.createGain();
    g2.gain.value = 0.45;
    o2.connect(g2);
    g2.connect(dg);
    o2.start();
    this.drone2 = o2;

    const lfo = ctx.createOscillator();
    lfo.frequency.value = 0.07;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 180;
    lfo.connect(lfoGain);
    lfoGain.connect(filter.frequency);
    lfo.start();
    this.lfo = lfo;

    this.scheduleBar();
  }

  stopMusic() {
    window.clearTimeout(this.musicHandle);
    try {
      this.drone?.stop();
      this.drone2?.stop();
      this.lfo?.stop();
    } catch {
      /* already stopped */
    }
    this.drone = null;
    this.drone2 = null;
    this.lfo = null;
  }

  shoot() {
    const now = performance.now();
    if (now - this.lastShot < 45) return;
    this.lastShot = now;
    this.blip(720 + Math.random() * 180, 0.045, 0.05, "square", 2.2);
  }

  explode(scale = 1) {
    this.noiseBurst(0.18 + scale * 0.12, 0.22 * Math.min(1.4, scale), 400 / scale, 90);
    this.blip(90 + Math.random() * 30, 0.16, 0.12 * scale, "sine", 4);
  }

  pickup() {
    this.blip(880, 0.07, 0.07, "sine", 1.6);
    this.blip(1320, 0.09, 0.05, "sine", 1.8);
  }

  hurt() {
    this.noiseBurst(0.16, 0.2, 700, 180);
    this.blip(140, 0.14, 0.14, "sawtooth", 3.5);
  }

  dash() {
    this.sweep(240, 980, 0.12, 0.08);
  }

  levelUp() {
    this.blip(523, 0.12, 0.1, "triangle");
    this.blip(659, 0.16, 0.09, "triangle");
    this.blip(784, 0.22, 0.08, "triangle");
  }

  ui() {
    this.blip(640, 0.06, 0.06, "triangle");
  }

  select() {
    this.blip(520, 0.08, 0.07, "sine");
    this.blip(780, 0.12, 0.05, "sine");
  }

  combo(n: number) {
    this.blip(420 + n * 18, 0.05, 0.04, "square");
  }

  boss() {
    this.noiseBurst(0.4, 0.28, 200, 60);
    this.blip(55, 0.5, 0.16, "sine", 2);
  }

  destroy() {
    this.stopMusic();
    void this.ctx?.close();
    this.ctx = null;
  }

  private scheduleBar() {
    if (!this.ctx || !this.music) return;
    const ctx = this.ctx;
    const bpm = 92 + this.intensity * 10;
    const eighth = 60 / bpm / 2;
    const t0 = ctx.currentTime + 0.04;
    const bass = [55, 55, 82.4, 73.4, 55, 65.4, 49, 55];
    const arp = [220, 261.6, 329.6, 392, 329.6, 261.6, 246.9, 220];
    const i = this.step % 8;

    this.pluck(bass[i], t0, 0.28, 0.07, "sine");
    if (this.intensity > 0.2 && i % 2 === 0) {
      this.pluck(arp[i] * 2, t0, 0.12, 0.018 + this.intensity * 0.01, "triangle");
    }
    if (this.intensity > 0.55 && i === 0) {
      this.pluck(110, t0, 0.4, 0.05, "triangle");
    }

    this.step++;
    this.musicHandle = window.setTimeout(() => this.scheduleBar(), eighth * 1000);
  }

  private pluck(freq: number, time: number, dur: number, gain: number, type: OscillatorType) {
    if (!this.ctx || !this.music) return;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    g.gain.setValueAtTime(gain, time);
    g.gain.exponentialRampToValueAtTime(0.0001, time + dur);
    osc.connect(g);
    g.connect(this.music);
    osc.start(time);
    osc.stop(time + dur + 0.02);
  }

  private blip(
    freq: number,
    dur: number,
    gain: number,
    type: OscillatorType,
    slide = 0,
  ) {
    if (!this.ctx || !this.sfx) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq / slide), t + dur);
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g);
    g.connect(this.sfx);
    osc.start(t);
    osc.stop(t + dur + 0.02);
  }

  private sweep(from: number, to: number, dur: number, gain: number) {
    if (!this.ctx || !this.sfx) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    const f = this.ctx.createBiquadFilter();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(from, t);
    osc.frequency.exponentialRampToValueAtTime(to, t + dur);
    f.type = "bandpass";
    f.frequency.value = 900;
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(f);
    f.connect(g);
    g.connect(this.sfx);
    osc.start(t);
    osc.stop(t + dur + 0.02);
  }

  private noiseBurst(dur: number, gain: number, startF: number, endF: number) {
    if (!this.ctx || !this.sfx || !this.noise) return;
    const t = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noise;
    const f = this.ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.setValueAtTime(startF, t);
    f.frequency.exponentialRampToValueAtTime(Math.max(40, endF), t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f);
    f.connect(g);
    g.connect(this.sfx);
    src.start(t);
    src.stop(t + dur + 0.02);
  }
}
